import java.util.*;

public class AnimeChatbot {
    private static final Map<String, List<String>> animeRecommendations = new HashMap<>();
    private static final Map<String, String> casualResponses = new HashMap<>();

    public static void main(String[] args) {
        initializeAnimeRecommendations();
        initializeCasualResponses();
        
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("You: ");
            String userInput = scanner.nextLine().toLowerCase();
            if (!respondToUserInput(userInput)) {
                break;
            }
        }
        System.out.println("Ruka: Have a nice day! See you again later!");
    }

    private static void initializeAnimeRecommendations() {
        animeRecommendations.put("action", Arrays.asList("Attack on Titan", "My Hero Academia", "One Piece", "Naruto"));
        animeRecommendations.put("adventure", Arrays.asList("Fullmetal Alchemist: Brotherhood", "Hunter x Hunter", "One Piece"));
        animeRecommendations.put("comedy", Arrays.asList("One Punch Man", "Gintama", "Konosuba", "Nichijou", "The Devil is a Part-Timer"));
        animeRecommendations.put("drama", Arrays.asList("Your Lie in April", "Clannad", "Anohana", "Violet Evergarden"));
        animeRecommendations.put("fantasy", Arrays.asList("Sword Art Online", "Attack on Titan", "Fullmetal Alchemist: Brotherhood"));
        animeRecommendations.put("sci-fi", Arrays.asList("Steins;Gate", "Cowboy Bebop", "Neon Genesis Evangelion", "Ghost in the Shell"));
        animeRecommendations.put("slice of life", Arrays.asList("K-On!", "Barakamon", "Hyouka", "March Comes in Like a Lion"));
    }

    private static void initializeCasualResponses() {
        casualResponses.put("how are you?", "I am working fine, so I guess I am alright! How about you?");
        casualResponses.put("i am ok", "That's nice to know.");
        casualResponses.put("what is your name?", "My name is Ruka.");
        casualResponses.put("who are you?", "I am Ruka. I am an anime suggesting chatbot.");
        casualResponses.put("what can you do?", "I am an anime suggesting chatbot. I can recommend anime based on genres.");
    }

    private static boolean respondToUserInput(String userInput) {
        if (userInput.contains("suggest") || userInput.contains("recommend")) {
            suggest();
            return true;
        } else if (casualResponses.containsKey(userInput)) {
            System.out.println("Ruka: " + casualResponses.get(userInput));
            return true;
        } else {
            System.out.println("Ruka: I couldn't quite understand you. Can you rephrase the sentence?");
            return true;
        }
    }

    private static void suggest() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Ruka: Enter your preferred genres (comma-separated): ");
            String userGenresInput = scanner.nextLine().toLowerCase();
            String[] userGenres = userGenresInput.split(",");
            List<String> recommendations = new ArrayList<>();
            for (String genre : userGenres) {
                String closestGenre = findClosestGenre(genre.trim());
                if (closestGenre != null) {
                    recommendations.addAll(animeRecommendations.get(closestGenre));
                }
            }
            if (!recommendations.isEmpty()) {
                System.out.println("\nRuka: Here are some anime recommendations for you:");
                Collections.shuffle(recommendations);
                for (String recommendation : recommendations.subList(0, Math.min(recommendations.size(), 3))) {
                    System.out.println("- " + recommendation);
                }
            } else {
                System.out.println("\nRuka: Sorry, I couldn't find any recommendations for the given genres.");
            }
            System.out.print("\nRuka: Would you like more recommendations? (yes/no): ");
            String continueChat = scanner.nextLine().toLowerCase();
            if (!continueChat.equals("yes") && !continueChat.equals("y")) {
                break;
            }
        }
    }

    private static String findClosestGenre(String userInput) {
        int maxRatio = 0;
        String closestGenre = null;
        for (String genre : animeRecommendations.keySet()) {
            int ratio = fuzzyRatio(userInput, genre);
            if (ratio > maxRatio) {
                maxRatio = ratio;
                closestGenre = genre;
            }
        }
        return closestGenre;
    }

    private static int fuzzyRatio(String userInput, String genre) {
        int[][] dp = new int[userInput.length() + 1][genre.length() + 1];

        for (int i = 0; i <= userInput.length(); i++) {
            dp[i][0] = i;
        }
        for (int j = 0; j <= genre.length(); j++) {
            dp[0][j] = j;
        }

        for (int i = 1; i <= userInput.length(); i++) {
            for (int j = 1; j <= genre.length(); j++) {
                if (userInput.charAt(i - 1) == genre.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(dp[i - 1][j - 1], Math.min(dp[i - 1][j], dp[i][j - 1]));
                }
            }
        }

        int maxLen = Math.max(userInput.length(), genre.length());
        return(int)(1 - dp[userInput.length()][genre.length()] / (double) maxLen) * 100;
    }
}
