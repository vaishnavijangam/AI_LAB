import java.util.Scanner;

public class NQueens {

    private static int[] queens; // To store column positions of queens
    private static int solutionsCount = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the size of the chessboard (n): ");
        int n = scanner.nextInt();
        scanner.close();

        queens = new int[n];
        solveNQueensBacktracking(0, n);// Call backtracking algorithm
        System.out.println("Total solutions using backtracking: " + solutionsCount);

        solutionsCount = 0;
        solveNQueensBranchAndBound(new boolean[n], new boolean[2 * n - 1], new boolean[2 * n - 1], 0, n);// Call branch and bound algorithm
        System.out.println("Total solutions using branch and bound: " + solutionsCount);
    }
// Backtracking algorithm for solving N-Queens problem
    private static void solveNQueensBacktracking(int row, int n) {
        if (row == n) { // Base case: all queens are placed successfully
            solutionsCount++;
            printSolution(n);
            return;
        }

        // Try placing a queen in each column of the current row
        for (int col = 0; col < n; col++) {
            if (isValidPosition(row, col, n)) { // Check if the position is valid
                queens[row] = col;// Place the queen
                solveNQueensBacktracking(row + 1, n);// Recur for the next row
            }
        }
    }
// Check if placing a queen at the given position is valid
    private static boolean isValidPosition(int row, int col, int n) {
        for (int prevRow = 0; prevRow < row; prevRow++) {
            int prevCol = queens[prevRow];
            // Check if the queen can attack any previously placed queen
            if (prevCol == col || Math.abs(prevRow - row) == Math.abs(prevCol - col)) {
                return false;
            }
        }
        return true;
    }
 // Print the solution
    private static void printSolution(int n) {
        System.out.print("Solution " + solutionsCount + ": ");
        for (int i = 0; i < n; i++) {
            System.out.print("(" + (i + 1) + "," + (queens[i] + 1) + ") ");
        }
        System.out.println();
    }
// Branch and Bound algorithm for solving N-Queens problem
    private static void solveNQueensBranchAndBound(boolean[] cols, boolean[] d1, boolean[] d2, int row, int n) {
        if (row == n) {// Base case: all queens are placed successfully
            solutionsCount++;
            return;
        }
// Try placing a queen in each column of the current row
        for (int col = 0; col < n; col++) {
            int id1 = col - row + n - 1;
            int id2 = col + row;
            if (!cols[col] && !d1[id1] && !d2[id2]) {// Check if the position is valid
                cols[col] = true;
                d1[id1] = true;
                d2[id2] = true;
                solveNQueensBranchAndBound(cols, d1, d2, row + 1, n);// Recur for the next row
                // Backtrack
                cols[col] = false;
                d1[id1] = false;
                d2[id2] = false;
            }
        }
    }
}
